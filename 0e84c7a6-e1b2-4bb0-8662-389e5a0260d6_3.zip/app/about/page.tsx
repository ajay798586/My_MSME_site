
'use client';

import Link from 'next/link';

export default function About() {
  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Link href="/">
                <h1 className="text-2xl font-bold text-blue-600 cursor-pointer" style={{fontFamily: 'var(--font-pacifico)'}}>
                  Startup with Ajay Bhai
                </h1>
              </Link>
            </div>
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-8">
                <Link href="/" className="text-gray-700 hover:text-blue-600 px-3 py-2 font-medium cursor-pointer">Home</Link>
                <Link href="/services" className="text-gray-700 hover:text-blue-600 px-3 py-2 font-medium cursor-pointer">Services</Link>
                <Link href="/about" className="text-blue-600 hover:text-blue-800 px-3 py-2 font-medium cursor-pointer">About</Link>
                <Link href="/blog" className="text-gray-700 hover:text-blue-600 px-3 py-2 font-medium cursor-pointer">Blog</Link>
                <Link href="/contact" className="text-gray-700 hover:text-blue-600 px-3 py-2 font-medium cursor-pointer">Contact</Link>
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-blue-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="text-white">
              <h1 className="text-5xl font-bold mb-6">About Ajay Kumar</h1>
              <p className="text-xl text-blue-100 mb-6">
                Your Trusted MSME Consultant from Soraon, Prayagraj
              </p>
              <p className="text-lg text-blue-200 leading-relaxed">
                With over 5+ years of experience in MSME consultancy, I have dedicated my career to empowering Indian entrepreneurs and helping them navigate the complex world of business registrations and government compliance.
              </p>
            </div>
            <div className="flex justify-center">
              <img 
                src="https://static.readdy.ai/image/5d82a13681e62b45fbcc2f4e8fd4caf5/9544a92e2489c7a3bf5367dc19042edf.png"
                alt="Ajay Kumar - MSME Consultant"
                className="w-80 h-96 object-cover object-top rounded-2xl shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Track Record</h2>
            <p className="text-xl text-gray-600">Numbers that speak for themselves</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[ 
              {
                number: "5+",
                label: "Years Experience",
                icon: "ri-time-line"
              },
              {
                number: "500+",
                label: "Business Registrations",
                icon: "ri-building-line"
              },
              {
                number: "300+",
                label: "Satisfied Clients",
                icon: "ri-user-smile-line"
              },
              {
                number: "50+",
                label: "Government Schemes",
                icon: "ri-government-line"
              }
            ].map((stat, index) => (
              <div key={index} className="text-center bg-white rounded-xl p-8 shadow-lg">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className={`${stat.icon} text-2xl text-blue-600`}></i>
                </div>
                <div className="text-4xl font-bold text-blue-600 mb-2">{stat.number}</div>
                <div className="text-gray-600 font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-gray-900 mb-8 text-center">My Story</h2>
          <div className="prose prose-lg mx-auto text-gray-700 leading-relaxed">
            <p className="text-xl mb-6">
              Born and raised in Soraon, Prayagraj, Uttar Pradesh, I witnessed firsthand the challenges that small business owners and entrepreneurs face when trying to establish and grow their ventures. This personal experience ignited my passion for helping others navigate the complex world of MSME regulations and government schemes.
            </p>
            <p className="text-lg mb-6">
              After completing my education and gaining valuable experience in business consultancy, I founded "Startup with Ajay Bhai" with a simple yet powerful mission: to make business registration and compliance accessible to every entrepreneur, regardless of their background or technical knowledge.
            </p>
            <p className="text-lg mb-6">
              Over the past 5+ years, I have successfully helped hundreds of businesses with their Udyam registration, GST compliance, loan applications, and accessing various government subsidies. My approach is personal, transparent, and focused on long-term relationships rather than one-time transactions.
            </p>
            <p className="text-lg">
              Today, I continue to serve entrepreneurs across India from my base in Soraon, Prayagraj, combining local understanding with national expertise to deliver exceptional results for my clients.
            </p>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div className="bg-blue-50 rounded-2xl p-8">
              <div className="w-16 h-16 bg-blue-100 rounded-lg flex items-center justify-center mb-6">
                <i className="ri-target-line text-2xl text-blue-600"></i>
              </div>
              <h3 className="text-3xl font-bold text-gray-900 mb-4">Our Mission</h3>
              <p className="text-lg text-gray-700 leading-relaxed">
                To empower every entrepreneur and small business owner in India by providing accessible, reliable, and comprehensive MSME consultancy services. We believe that every business idea deserves the right support to flourish and contribute to India's economic growth.
              </p>
            </div>
            <div className="bg-orange-50 rounded-2xl p-8">
              <div className="w-16 h-16 bg-orange-100 rounded-lg flex items-center justify-center mb-6">
                <i className="ri-eye-line text-2xl text-orange-600"></i>
              </div>
              <h3 className="text-3xl font-bold text-gray-900 mb-4">Our Vision</h3>
              <p className="text-lg text-gray-700 leading-relaxed">
                To become the most trusted MSME consultancy in India, known for our integrity, expertise, and commitment to client success. We envision a future where every entrepreneur has easy access to the resources and guidance they need to build successful businesses.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Values</h2>
            <p className="text-xl text-gray-600">The principles that guide everything we do</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[ 
              {
                icon: "ri-hand-heart-line",
                title: "Integrity",
                description: "We operate with complete transparency and honesty in all our dealings, ensuring our clients always know what to expect."
              },
              {
                icon: "ri-lightbulb-line",
                title: "Expertise",
                description: "Our deep knowledge of MSME regulations and government schemes ensures the best possible outcomes for our clients."
              },
              {
                icon: "ri-customer-service-line",
                title: "Client-First",
                description: "Every decision we make is centered around what's best for our clients and their business success."
              },
              {
                icon: "ri-time-line",
                title: "Reliability",
                description: "We deliver on our promises within agreed timelines, ensuring your business operations are never delayed."
              },
              {
                icon: "ri-phone-line",
                title: "Accessibility",
                description: "We're always available when you need us, providing support and guidance throughout your business journey."
              },
              {
                icon: "ri-trophy-line",
                title: "Excellence",
                description: "We strive for excellence in everything we do, continuously improving our services and expertise."
              }
            ].map((value, index) => (
              <div key={index} className="bg-white rounded-xl p-8 shadow-lg text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <i className={`${value.icon} text-2xl text-blue-600`}></i>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">{value.title}</h3>
                <p className="text-gray-600 leading-relaxed">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-blue-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Work Together?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Let's discuss how I can help you achieve your business goals and navigate the MSME landscape successfully.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="https://wa.me/917985867696" 
              target="_blank" 
              rel="noopener noreferrer"
              className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-lg font-semibold text-lg inline-flex items-center justify-center whitespace-nowrap cursor-pointer transition-colors"
            >
              <i className="ri-whatsapp-line mr-2 text-xl"></i>
              Chat on WhatsApp
            </a>
            <Link 
              href="/contact"
              className="bg-transparent border-2 border-white text-white hover:bg-white hover:text-blue-600 px-8 py-4 rounded-lg font-semibold text-lg inline-flex items-center justify-center whitespace-nowrap cursor-pointer transition-colors"
            >
              <i className="ri-phone-line mr-2"></i>
              Get in Touch
            </Link>
          </div>
        </div>
      </section>

      {/* WhatsApp Float Button */}
      <a 
        href="https://wa.me/917985867696" 
        target="_blank" 
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 bg-green-500 hover:bg-green-600 text-white w-16 h-16 rounded-full flex items-center justify-center shadow-lg z-50 cursor-pointer transition-colors"
      >
        <i className="ri-whatsapp-line text-2xl"></i>
      </a>
    </div>
  );
}
