
'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Home() {
  const [language, setLanguage] = useState('en');

  const toggleLanguage = () => {
    setLanguage(prev => prev === 'en' ? 'hi' : 'en');
  };

  const content = {
    en: {
      nav: {
        home: 'Home',
        services: 'Services',
        about: 'About',
        blog: 'Blog',
        contact: 'Contact'
      },
      hero: {
        title: 'Empowering Your',
        titleHighlight: 'MSME Journey',
        titleEnd: 'with Expert Guidance',
        tagline: 'Complete Business Solutions & MSME Advisory',
        description: 'With over 5+ years of experience, I help Indian entrepreneurs and startups with registrations, subsidies, and business compliance in Soraon, Prayagraj.',
        ctaPrimary: 'Get Free Consultation Now',
        ctaSecondary: 'Explore Services'
      },
      services: {
        title: 'Our Services',
        subtitle: 'Comprehensive MSME solutions to help your business grow and thrive in today\'s competitive market'
      },
      about: {
        title: 'About Ajay Kumar',
        description1: 'With over 5+ years of dedicated experience in MSME consultancy, I have been helping Indian entrepreneurs and startups navigate the complex world of business registrations, government schemes, and compliance requirements.',
        description2: 'Based in Soraon, Prayagraj, Uttar Pradesh, my mission is to empower small and medium enterprises by providing expert guidance on Udyam registration, funding opportunities, and accessing various government subsidies that can accelerate business growth.'
      }
    },
    hi: {
      nav: {
        home: 'होम',
        services: 'सेवाएं',
        about: 'हमारे बारे में',
        blog: 'ब्लॉग',
        contact: 'संपर्क'
      },
      hero: {
        title: 'आपकी',
        titleHighlight: 'MSME यात्रा',
        titleEnd: 'को विशेषज्ञ मार्गदर्शन के साथ सशक्त बनाना',
        tagline: 'संपूर्ण व्यापारिक समाधान और MSME सलाहकार',
        description: '5+ वर्षों के अनुभव के साथ, मैं सोरांव, प्रयागराज में भारतीय उद्यमियों और स्टार्टअप्स की पंजीकरण, सब्सिडी और व्यापारिक अनुपालन में सहायता करता हूं।',
        ctaPrimary: 'निःशुल्क परामर्श लें',
        ctaSecondary: 'सेवाओं का अन्वेषण करें'
      },
      services: {
        title: 'हमारी सेवाएं',
        subtitle: 'आज के प्रतिस्पर्धी बाजार में आपके व्यापार को बढ़ने और फलने-फूलने में मदद करने के लिए व्यापक MSME समाधान'
      },
      about: {
        title: 'अजय कुमार के बारे में',
        description1: 'MSME सलाहकार में 5+ वर्षों के समर्पित अनुभव के साथ, मैं भारतीय उद्यमियों और स्टार्टअप्स को व्यापारिक पंजीकरण, सरकारी योजनाओं और अनुपालन आवश्यकताओं की जटिल दुनिया में नेविगेट करने में मदद कर रहा हूं।',
        description2: 'सोरांव, प्रयागराज, उत्तर प्रदेश में स्थित, मेरा मिशन छोटे और मध्यम उद्यमों को उद्यम पंजीकरण, फंडिंग के अवसरों और विभिन्न सरकारी सब्सिडी तक पहुंच पर विशेषज्ञ मार्गदर्शन प्रदान करके सशक्त बनाना है।'
      }
    }
  };

  const currentContent = content[language as keyof typeof content];

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-blue-600" style={{fontFamily: 'var(--font-pacifico)'}}>
                Startup with Ajay Bhai
              </h1>
            </div>
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-8">
                <Link href="/" className="text-blue-600 hover:text-blue-800 px-3 py-2 font-medium cursor-pointer">{currentContent.nav.home}</Link>
                <Link href="/services" className="text-gray-700 hover:text-blue-600 px-3 py-2 font-medium cursor-pointer">{currentContent.nav.services}</Link>
                <Link href="/about" className="text-gray-700 hover:text-blue-600 px-3 py-2 font-medium cursor-pointer">{currentContent.nav.about}</Link>
                <Link href="/blog" className="text-gray-700 hover:text-blue-600 px-3 py-2 font-medium cursor-pointer">{currentContent.nav.blog}</Link>
                <Link href="/contact" className="text-gray-700 hover:text-blue-600 px-3 py-2 font-medium cursor-pointer">{currentContent.nav.contact}</Link>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <button
                onClick={toggleLanguage}
                className="flex items-center space-x-2 px-3 py-2 rounded-lg border border-gray-300 hover:bg-gray-50 cursor-pointer transition-colors"
              >
                <i className="ri-global-line text-gray-600"></i>
                <span className="text-gray-700 font-medium">{language === 'en' ? 'हिंदी' : 'English'}</span>
              </button>
              <div className="md:hidden">
                <button className="text-gray-700 hover:text-blue-600">
                  <i className="ri-menu-line text-2xl"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section 
        className="relative bg-cover bg-center bg-no-repeat min-h-screen flex items-center"
        style={{
          backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)), url('https://readdy.ai/api/search-image?query=Professional%20modern%20office%20environment%20with%20business%20consultation%20setup%2C%20clean%20minimal%20workspace%20with%20documents%20and%20laptop%2C%20soft%20natural%20lighting%2C%20contemporary%20interior%20design%20with%20blue%20and%20white%20color%20scheme%2C%20business%20meeting%20atmosphere%2C%20professional%20consulting%20ambiance%2C%20high-quality%20corporate%20photography&width=1920&height=1080&seq=hero-bg-001&orientation=landscape')`
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="text-white">
              <h1 className="text-5xl lg:text-6xl font-bold mb-6 leading-tight">
                {currentContent.hero.title} <span className="text-orange-400">{currentContent.hero.titleHighlight}</span> {currentContent.hero.titleEnd}
              </h1>
              <p className="text-xl mb-4 text-gray-200">
                {currentContent.hero.tagline}
              </p>
              <p className="text-lg mb-8 text-gray-300 leading-relaxed">
                {currentContent.hero.description}
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <a 
                  href="https://wa.me/917985867696" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-lg font-semibold text-lg inline-flex items-center justify-center whitespace-nowrap cursor-pointer transition-colors"
                >
                  <i className="ri-whatsapp-line mr-2 text-xl"></i>
                  {currentContent.hero.ctaPrimary}
                </a>
                <Link 
                  href="/services"
                  className="bg-transparent border-2 border-white text-white hover:bg-white hover:text-blue-600 px-8 py-4 rounded-lg font-semibold text-lg inline-flex items-center justify-center whitespace-nowrap cursor-pointer transition-colors"
                >
                  {currentContent.hero.ctaSecondary}
                </Link>
              </div>
            </div>
            <div className="flex justify-center lg:justify-end">
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 max-w-md">
                <img 
                  src="https://static.readdy.ai/image/5d82a13681e62b45fbcc2f4e8fd4caf5/9544a92e2489c7a3bf5367dc19042edf.png"
                  alt="Ajay Kumar - MSME Consultant"
                  className="w-full h-80 object-cover object-top rounded-xl mb-4"
                />
                <div className="text-center text-white">
                  <h3 className="text-2xl font-bold mb-2">Ajay Kumar</h3>
                  <p className="text-gray-200 mb-2">MSME Consultant</p>
                  <p className="text-sm text-gray-300">Soraon, Prayagraj, UP</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Overview */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">{currentContent.services.title}</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">{currentContent.services.subtitle}</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[ 
              {
                icon: "ri-building-line",
                title: "MSME/Udyam Registration",
                description: "Complete registration process for your MSME with government compliance"
              },
              {
                icon: "ri-calculator-line",
                title: "GST & Tax Consultation",
                description: "Expert guidance on GST registration, filing, and tax compliance matters"
              },
              {
                icon: "ri-money-dollar-circle-line",
                title: "Business Loan Assistance",
                description: "Help securing business loans and grants for your enterprise growth"
              },
              {
                icon: "ri-shield-check-line",
                title: "Compliance Support",
                description: "Ensure your business meets all regulatory requirements and standards"
              },
              {
                icon: "ri-file-text-line",
                title: "Project Report Preparation",
                description: "Professional project reports for loan applications and investors"
              },
              {
                icon: "ri-government-line",
                title: "Government Schemes",
                description: "Access to various government subsidies and schemes for MSMEs"
              }
            ].map((service, index) => (
              <div key={index} className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow cursor-pointer">
                <div className="w-16 h-16 bg-blue-100 rounded-lg flex items-center justify-center mb-6">
                  <i className={`${service.icon} text-2xl text-blue-600`}></i>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">{service.title}</h3>
                <p className="text-gray-600 leading-relaxed">{service.description}</p>
              </div>
            ))}
          </div>
          <div className="text-center mt-12">
            <Link 
              href="/services"
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-lg font-semibold text-lg inline-flex items-center whitespace-nowrap cursor-pointer transition-colors"
            >
              View All Services
              <i className="ri-arrow-right-line ml-2"></i>
            </Link>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <img 
                src="https://readdy.ai/api/search-image?query=Professional%20Indian%20business%20consultant%20in%20modern%20office%20setting%2C%20wearing%20formal%20attire%2C%20confident%20posture%2C%20modern%20workspace%20background%2C%20natural%20lighting%2C%20high-quality%20corporate%20portrait%20photography%2C%20business%20professional%20atmosphere%2C%20contemporary%20office%20interior&width=600&height=700&seq=about-img-001&orientation=portrait"
                alt="About Ajay Kumar"
                className="w-full h-96 object-cover object-top rounded-2xl shadow-lg"
              />
            </div>
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">{currentContent.about.title}</h2>
              <p className="text-lg text-gray-700 mb-6 leading-relaxed">
                {currentContent.about.description1}
              </p>
              <p className="text-lg text-gray-700 mb-6 leading-relaxed">
                {currentContent.about.description2}
              </p>
              <div className="space-y-4 mb-8">
                <div className="flex items-center">
                  <i className="ri-check-line text-green-600 text-xl mr-3"></i>
                  <span className="text-gray-700">5+ Years of MSME Consulting Experience</span>
                </div>
                <div className="flex items-center">
                  <i className="ri-check-line text-green-600 text-xl mr-3"></i>
                  <span className="text-gray-700">500+ Successful Business Registrations</span>
                </div>
                <div className="flex items-center">
                  <i className="ri-check-line text-green-600 text-xl mr-3"></i>
                  <span className="text-gray-700">Expert in Government Schemes & Subsidies</span>
                </div>
                <div className="flex items-center">
                  <i className="ri-check-line text-green-600 text-xl mr-3"></i>
                  <span className="text-gray-700">Based in Soraon, Prayagraj, UP</span>
                </div>
              </div>
              <Link 
                href="/about"
                className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-lg font-semibold inline-flex items-center whitespace-nowrap cursor-pointer transition-colors"
              >
                Learn More About Me
                <i className="ri-arrow-right-line ml-2"></i>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Client Testimonials */}
      <section className="py-20 bg-gradient-to-r from-blue-50 to-orange-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Client Testimonials</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              See what our satisfied clients say about our MSME consulting services
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                name: "Rajesh Sharma",
                business: "Sharma Electronics Pvt Ltd",
                location: "Kanpur, UP",
                rating: 5,
                testimonial: "Ajay Bhai helped us complete our Udyam registration in just 3 days. His expertise in government schemes saved us ₹50,000 in subsidies. Highly professional and reliable service!",
                image: "https://readdy.ai/api/search-image?query=Professional%20Indian%20businessman%20in%20formal%20attire%2C%20confident%20smile%2C%20modern%20office%20background%2C%20corporate%20headshot%20photography%2C%20middle-aged%20male%20entrepreneur%2C%20business%20professional%20portrait&width=150&height=150&seq=client-001&orientation=squarish"
              },
              {
                name: "Priya Gupta",
                business: "Fresh Foods Manufacturing",
                location: "Lucknow, UP",
                rating: 5,
                testimonial: "Excellent guidance for our GST registration and compliance. Ajay Bhai's team is always available for support. They made the entire process smooth and hassle-free for our food business.",
                image: "https://readdy.ai/api/search-image?query=Professional%20Indian%20businesswoman%20in%20formal%20attire%2C%20confident%20expression%2C%20modern%20office%20setting%2C%20corporate%20headshot%20photography%2C%20female%20entrepreneur%20portrait%2C%20business%20professional&width=150&height=150&seq=client-002&orientation=squarish"
              },
              {
                name: "Vikram Singh",
                business: "Tech Solutions Startup",
                location: "Varanasi, UP",
                rating: 5,
                testimonial: "Got our startup registered under Startup India scheme with Ajay Bhai's help. His knowledge of latest government policies is exceptional. Received ₹2 lakh grant through his guidance!",
                image: "https://readdy.ai/api/search-image?query=Young%20Indian%20entrepreneur%20in%20casual%20formal%20attire%2C%20tech%20startup%20founder%2C%20modern%20workspace%20background%2C%20professional%20portrait%20photography%2C%20male%20business%20owner&width=150&height=150&seq=client-003&orientation=squarish"
              }
            ].map((testimonial, index) => (
              <div key={index} className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow">
                <div className="flex items-center mb-6">
                  <img 
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-16 h-16 rounded-full object-cover object-top mr-4"
                  />
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900">{testimonial.name}</h4>
                    <p className="text-sm text-gray-600">{testimonial.business}</p>
                    <p className="text-sm text-gray-500">{testimonial.location}</p>
                  </div>
                </div>
                <div className="flex items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <i key={i} className="ri-star-fill text-yellow-400 text-lg"></i>
                  ))}
                </div>
                <p className="text-gray-700 leading-relaxed italic">
                  "{testimonial.testimonial}"
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Downloadable Forms Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Download Forms & Documents</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Access essential forms and checklists for your MSME registration and compliance needs
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                icon: "ri-file-pdf-line",
                title: "Udyam Registration Form",
                description: "Complete application form for MSME registration",
                downloads: "2.5K+ Downloads"
              },
              {
                icon: "ri-file-pdf-line",
                title: "GST Registration Checklist",
                description: "Document checklist for GST registration process",
                downloads: "1.8K+ Downloads"
              },
              {
                icon: "ri-file-pdf-line",
                title: "Loan Application Guide",
                description: "Step-by-step guide for business loan applications",
                downloads: "3.2K+ Downloads"
              },
              {
                icon: "ri-file-pdf-line",
                title: "Government Schemes List",
                description: "Updated list of available MSME schemes 2024",
                downloads: "4.1K+ Downloads"
              }
            ].map((form, index) => (
              <div key={index} className="bg-gray-50 rounded-xl p-6 text-center hover:bg-gray-100 transition-colors cursor-pointer">
                <div className="w-16 h-16 bg-red-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <i className={`${form.icon} text-2xl text-red-600`}></i>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{form.title}</h3>
                <p className="text-gray-600 text-sm mb-4">{form.description}</p>
                <p className="text-xs text-gray-500 mb-4">{form.downloads}</p>
                <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap cursor-pointer transition-colors">
                  <i className="ri-download-line mr-2"></i>
                  Download PDF
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-blue-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Start Your MSME Journey?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Get expert guidance on business registration, compliance, and accessing government schemes. Let's build your business together.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="https://wa.me/917985867696" 
              target="_blank" 
              rel="noopener noreferrer"
              className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-lg font-semibold text-lg inline-flex items-center justify-center whitespace-nowrap cursor-pointer transition-colors"
            >
              <i className="ri-whatsapp-line mr-2 text-xl"></i>
              WhatsApp Consultation
            </a>
            <Link 
              href="/contact"
              className="bg-transparent border-2 border-white text-white hover:bg-white hover:text-blue-600 px-8 py-4 rounded-lg font-semibold text-lg inline-flex items-center justify-center whitespace-nowrap cursor-pointer transition-colors"
            >
              <i className="ri-phone-line mr-2"></i>
              Call Now
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div>
              <h3 className="text-2xl font-bold mb-4" style={{fontFamily: 'var(--font-pacifico)'}}>
                Startup with Ajay Bhai
              </h3>
              <p className="text-gray-400 mb-4">
                Complete Business Solutions & MSME Advisory
              </p>
              <p className="text-gray-400">
                Empowering entrepreneurs across India with expert guidance and comprehensive business solutions.
              </p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li><Link href="/" className="text-gray-400 hover:text-white cursor-pointer">Home</Link></li>
                <li><Link href="/services" className="text-gray-400 hover:text-white cursor-pointer">Services</Link></li>
                <li><Link href="/about" className="text-gray-400 hover:text-white cursor-pointer">About</Link></li>
                <li><Link href="/blog" className="text-gray-400 hover:text-white cursor-pointer">Blog</Link></li>
                <li><Link href="/contact" className="text-gray-400 hover:text-white cursor-pointer">Contact</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Services</h4>
              <ul className="space-y-2">
                <li><span className="text-gray-400">MSME Registration</span></li>
                <li><span className="text-gray-400">GST Consultation</span></li>
                <li><span className="text-gray-400">Business Loans</span></li>
                <li><span className="text-gray-400">Compliance Support</span></li>
                <li><span className="text-gray-400">Government Schemes</span></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Contact Info</h4>
              <div className="space-y-3">
                <div className="flex items-center">
                  <i className="ri-phone-line text-orange-500 mr-3"></i>
                  <span className="text-gray-400">+91 7985867696</span>
                </div>
                <div className="flex items-center">
                  <i className="ri-mail-line text-orange-500 mr-3"></i>
                  <span className="text-gray-400">freelancer.ajaykumar@gmail.com</span>
                </div>
                <div className="flex items-center">
                  <i className="ri-map-pin-line text-orange-500 mr-3"></i>
                  <span className="text-gray-400">Soraon, Prayagraj, UP - 212502</span>
                </div>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-12 pt-8 text-center">
            <p className="text-gray-400">
              2024 Startup with Ajay Bhai. All rights reserved.
            </p>
          </div>
        </div>
      </footer>

      {/* WhatsApp Float Button */}
      <a 
        href="https://wa.me/917985867696" 
        target="_blank" 
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 bg-green-500 hover:bg-green-600 text-white w-16 h-16 rounded-full flex items-center justify-center shadow-lg z-50 cursor-pointer transition-colors"
      >
        <i className="ri-whatsapp-line text-2xl"></i>
      </a>

      {/* Live Chat Widget */}
      <div className="fixed bottom-6 left-6 bg-blue-600 hover:bg-blue-700 text-white w-16 h-16 rounded-full flex items-center justify-center shadow-lg z-50 cursor-pointer transition-colors">
        <i className="ri-chat-3-line text-2xl"></i>
      </div>
    </div>
  );
}
