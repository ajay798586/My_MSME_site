
'use client';

import Link from 'next/link';

export default function Services() {
  const services = [
    {
      icon: "ri-building-line",
      title: "MSME/Udyam Registration",
      description: "Complete registration process for your MSME with government compliance and certification.",
      features: [
        "Online Udyam Registration",
        "Certificate Processing",
        "Compliance Documentation",
        "Post-Registration Support"
      ],
      price: "Starting from ₹2,999"
    },
    {
      icon: "ri-calculator-line",
      title: "GST & Tax Consultation",
      description: "Expert guidance on GST registration, filing, and comprehensive tax compliance matters.",
      features: [
        "GST Registration",
        "Monthly/Quarterly Filing",
        "Tax Planning & Advisory",
        "Audit Support"
      ],
      price: "Starting from ₹1,999"
    },
    {
      icon: "ri-money-dollar-circle-line",
      title: "Business Loan / Grant Assistance",
      description: "Professional help in securing business loans and grants for enterprise growth and expansion.",
      features: [
        "Loan Application Processing",
        "Documentation Support",
        "Bank Liaison Services",
        "Grant Opportunity Identification"
      ],
      price: "Starting from ₹4,999"
    },
    {
      icon: "ri-shield-check-line",
      title: "Compliance Support",
      description: "Ensure your business meets all regulatory requirements and industry standards.",
      features: [
        "Legal Compliance Audit",
        "Regulatory Documentation",
        "Policy Development",
        "Ongoing Compliance Monitoring"
      ],
      price: "Starting from ₹3,999"
    },
    {
      icon: "ri-file-text-line",
      title: "Project Report Preparation",
      description: "Professional project reports for loan applications, investors, and business planning.",
      features: [
        "Detailed Project Analysis",
        "Financial Projections",
        "Market Research",
        "Investment Proposals"
      ],
      price: "Starting from ₹5,999"
    },
    {
      icon: "ri-government-line",
      title: "Government Schemes & Subsidy Guidance",
      description: "Access various government subsidies and schemes designed for MSME growth and development.",
      features: [
        "Scheme Identification",
        "Application Processing",
        "Documentation Support",
        "Follow-up Services"
      ],
      price: "Starting from ₹2,499"
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Link href="/">
                <h1 className="text-2xl font-bold text-blue-600 cursor-pointer" style={{fontFamily: 'var(--font-pacifico)'}}>
                  Startup with Ajay Bhai
                </h1>
              </Link>
            </div>
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-8">
                <Link href="/" className="text-gray-700 hover:text-blue-600 px-3 py-2 font-medium cursor-pointer">Home</Link>
                <Link href="/services" className="text-blue-600 hover:text-blue-800 px-3 py-2 font-medium cursor-pointer">Services</Link>
                <Link href="/about" className="text-gray-700 hover:text-blue-600 px-3 py-2 font-medium cursor-pointer">About</Link>
                <Link href="/blog" className="text-gray-700 hover:text-blue-600 px-3 py-2 font-medium cursor-pointer">Blog</Link>
                <Link href="/contact" className="text-gray-700 hover:text-blue-600 px-3 py-2 font-medium cursor-pointer">Contact</Link>
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-800 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold text-white mb-6">Our Services</h1>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto">
            Comprehensive MSME solutions designed to help your business succeed in today's competitive market
          </p>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div key={index} className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow p-8 border border-gray-100">
                <div className="w-16 h-16 bg-blue-100 rounded-lg flex items-center justify-center mb-6">
                  <i className={`${service.icon} text-2xl text-blue-600`}></i>
                </div>
                <h3 className="text-2xl font-semibold text-gray-900 mb-4">{service.title}</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">{service.description}</p>
                <ul className="space-y-2 mb-6">
                  {service.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center text-gray-700">
                      <i className="ri-check-line text-green-500 mr-2"></i>
                      {feature}
                    </li>
                  ))}
                </ul>
                <div className="border-t pt-6">
                  <p className="text-2xl font-bold text-blue-600 mb-4">{service.price}</p>
                  <a 
                    href="https://wa.me/917985867696" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="w-full bg-orange-500 hover:bg-orange-600 text-white py-3 px-6 rounded-lg font-semibold text-center inline-block whitespace-nowrap cursor-pointer transition-colors"
                  >
                    Get Quote
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Process</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Simple, transparent, and efficient process to get your business needs fulfilled
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              {
                step: "01",
                title: "Consultation",
                description: "Free initial consultation to understand your business needs and requirements"
              },
              {
                step: "02",
                title: "Documentation",
                description: "We help gather and prepare all necessary documents for your application"
              },
              {
                step: "03",
                title: "Application",
                description: "Submit applications with proper documentation and follow government procedures"
              },
              {
                step: "04",
                title: "Follow-up",
                description: "Regular updates and follow-up until successful completion of your requirements"
              }
            ].map((item, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-orange-500 text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-4">
                  {item.step}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{item.title}</h3>
                <p className="text-gray-600 leading-relaxed">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-blue-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Need Help with Your Business?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Contact us today for a free consultation and let us help you navigate your MSME journey successfully.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="https://wa.me/917985867696" 
              target="_blank" 
              rel="noopener noreferrer"
              className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-lg font-semibold text-lg inline-flex items-center justify-center whitespace-nowrap cursor-pointer transition-colors"
            >
              <i className="ri-whatsapp-line mr-2 text-xl"></i>
              WhatsApp Now
            </a>
            <Link 
              href="/contact"
              className="bg-transparent border-2 border-white text-white hover:bg-white hover:text-blue-600 px-8 py-4 rounded-lg font-semibold text-lg inline-flex items-center justify-center whitespace-nowrap cursor-pointer transition-colors"
            >
              <i className="ri-phone-line mr-2"></i>
              Call Us
            </Link>
          </div>
        </div>
      </section>

      {/* WhatsApp Float Button */}
      <a 
        href="https://wa.me/917985867696" 
        target="_blank" 
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 bg-green-500 hover:bg-green-600 text-white w-16 h-16 rounded-full flex items-center justify-center shadow-lg z-50 cursor-pointer transition-colors"
      >
        <i className="ri-whatsapp-line text-2xl"></i>
      </a>
    </div>
  );
}
