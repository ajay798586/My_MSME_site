
import type { Metadata } from "next";
import { Geist, Geist_Mono, Pacifico } from "next/font/google";
import "./globals.css";

const pacifico = Pacifico({
  weight: '400',
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-pacifico',
})

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "MSME Consultant in Prayagraj | Startup with Ajay Bhai | Udyam Registration Expert",
  description: "Leading MSME Consultant in Soraon, Prayagraj. Expert in Udyam Registration, GST Consultation, Business Loans & Government Schemes. 5+ years experience helping Indian entrepreneurs and startups with business compliance and subsidies.",
  keywords: "MSME Consultant in Prayagraj, Udyam Registration Expert in India, Startup Consultant for New Businesses, GST Registration Prayagraj, Business Loan Assistance UP, Government Schemes for MSME, Soraon Business Consultant, MSME Registration Uttar Pradesh",
  openGraph: {
    title: "MSME Consultant in Prayagraj | Startup with Ajay Bhai",
    description: "Expert MSME Consultant with 5+ years experience. Specializing in Udyam Registration, GST Consultation, and Government Schemes for Indian entrepreneurs.",
    type: "website",
    locale: "en_IN",
    siteName: "Startup with Ajay Bhai"
  },
  twitter: {
    card: "summary_large_image",
    title: "MSME Consultant in Prayagraj | Startup with Ajay Bhai",
    description: "Expert MSME Consultant with 5+ years experience in Udyam Registration and Government Schemes"
  },
  robots: "index, follow",
  authors: [{ name: "Ajay Kumar", url: "https://startup-with-ajay-bhai.com" }],
  category: "Business Consulting"
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning={true}>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="geo.region" content="IN-UP" />
        <meta name="geo.placename" content="Soraon, Prayagraj" />
        <meta name="geo.position" content="25.4358;81.8791" />
        <meta name="ICBM" content="25.4358, 81.8791" />
        <link rel="canonical" href="https://startup-with-ajay-bhai.com" />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "ProfessionalService",
              "name": "Startup with Ajay Bhai",
              "description": "MSME Consultant specializing in Udyam Registration, GST Consultation, and Government Schemes",
              "url": "https://startup-with-ajay-bhai.com",
              "telephone": "+91-7985867696",
              "email": "freelancer.ajaykumar@gmail.com",
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "Soraon",
                "addressLocality": "Prayagraj",
                "addressRegion": "Uttar Pradesh",
                "postalCode": "212502",
                "addressCountry": "IN"
              },
              "geo": {
                "@type": "GeoCoordinates",
                "latitude": "25.4358",
                "longitude": "81.8791"
              },
              "founder": {
                "@type": "Person",
                "name": "Ajay Kumar",
                "jobTitle": "MSME Consultant"
              },
              "serviceArea": "India",
              "priceRange": "₹₹",
              "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": "5",
                "reviewCount": "500"
              }
            })
          }}
        />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${pacifico.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
