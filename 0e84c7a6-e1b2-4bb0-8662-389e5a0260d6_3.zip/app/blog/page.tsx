
'use client';

import Link from 'next/link';

export default function Blog() {
  const blogPosts = [
    {
      id: 1,
      title: "Complete Guide to Udyam Registration 2024",
      excerpt: "Everything you need to know about MSME Udyam registration process, documents required, and benefits for your business.",
      category: "MSME Registration",
      readTime: "5 min read",
      date: "March 15, 2024",
      image: "https://readdy.ai/api/search-image?query=Professional%20business%20registration%20documents%20on%20desk%20with%20laptop%2C%20official%20government%20forms%2C%20business%20certificate%2C%20modern%20office%20setting%2C%20clean%20organized%20workspace%2C%20Indian%20business%20documentation%2C%20professional%20photography&width=400&height=250&seq=blog-001&orientation=landscape"
    },
    {
      id: 2,
      title: "Top 10 Government Schemes for MSMEs in 2024",
      excerpt: "Discover the latest government schemes and subsidies available for small and medium enterprises to boost your business growth.",
      category: "Government Schemes",
      readTime: "7 min read",
      date: "March 12, 2024",
      image: "https://readdy.ai/api/search-image?query=Indian%20government%20building%20with%20business%20growth%20charts%20and%20financial%20documents%2C%20official%20schemes%20and%20subsidies%20visual%20representation%2C%20professional%20business%20analysis%2C%20economic%20development%20graphics&width=400&height=250&seq=blog-002&orientation=landscape"
    },
    {
      id: 3,
      title: "GST Registration: Step-by-Step Process",
      excerpt: "Comprehensive guide to GST registration for new businesses, including required documents and common mistakes to avoid.",
      category: "Tax & Compliance",
      readTime: "6 min read",
      date: "March 10, 2024",
      image: "https://readdy.ai/api/search-image?query=GST%20tax%20calculation%20documents%20with%20calculator%20and%20laptop%2C%20Indian%20tax%20forms%20and%20certificates%2C%20professional%20accounting%20workspace%2C%20financial%20compliance%20materials%2C%20business%20tax%20preparation&width=400&height=250&seq=blog-003&orientation=landscape"
    },
    {
      id: 4,
      title: "Business Loan Application: Essential Tips",
      excerpt: "Learn how to prepare a successful business loan application with proper documentation and project reports.",
      category: "Business Finance",
      readTime: "8 min read",
      date: "March 8, 2024",
      image: "https://readdy.ai/api/search-image?query=Business%20loan%20application%20documents%20with%20bank%20forms%2C%20financial%20charts%20and%20graphs%2C%20professional%20business%20planning%20materials%2C%20loan%20approval%20process%20visualization%2C%20modern%20banking%20environment&width=400&height=250&seq=blog-004&orientation=landscape"
    },
    {
      id: 5,
      title: "MSME Compliance Checklist 2024",
      excerpt: "Stay compliant with all MSME regulations using our comprehensive checklist for small and medium enterprises.",
      category: "Compliance",
      readTime: "4 min read",
      date: "March 5, 2024",
      image: "https://readdy.ai/api/search-image?query=Business%20compliance%20checklist%20with%20checkmarks%2C%20regulatory%20documents%20and%20legal%20forms%2C%20professional%20compliance%20audit%20materials%2C%20organized%20office%20desk%20with%20legal%20paperwork&width=400&height=250&seq=blog-005&orientation=landscape"
    },
    {
      id: 6,
      title: "Startup India Registration Benefits",
      excerpt: "Explore the advantages of registering under Startup India scheme and how it can accelerate your business growth.",
      category: "Startup Registration",
      readTime: "5 min read",
      date: "March 3, 2024",
      image: "https://readdy.ai/api/search-image?query=Indian%20startup%20ecosystem%20with%20innovative%20technology%2C%20business%20incubation%20environment%2C%20modern%20startup%20office%20space%2C%20entrepreneurship%20development%20visual%2C%20startup%20india%20program%20representation&width=400&height=250&seq=blog-006&orientation=landscape"
    }
  ];

  const categories = [
    "All Posts",
    "MSME Registration",
    "Government Schemes",
    "Tax & Compliance",
    "Business Finance",
    "Compliance",
    "Startup Registration"
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Link href="/">
                <h1 className="text-2xl font-bold text-blue-600 cursor-pointer" style={{fontFamily: 'var(--font-pacifico)'}}>
                  Startup with Ajay Bhai
                </h1>
              </Link>
            </div>
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-8">
                <Link href="/" className="text-gray-700 hover:text-blue-600 px-3 py-2 font-medium cursor-pointer">Home</Link>
                <Link href="/services" className="text-gray-700 hover:text-blue-600 px-3 py-2 font-medium cursor-pointer">Services</Link>
                <Link href="/about" className="text-gray-700 hover:text-blue-600 px-3 py-2 font-medium cursor-pointer">About</Link>
                <Link href="/blog" className="text-blue-600 hover:text-blue-800 px-3 py-2 font-medium cursor-pointer">Blog</Link>
                <Link href="/contact" className="text-gray-700 hover:text-blue-600 px-3 py-2 font-medium cursor-pointer">Contact</Link>
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-800 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold text-white mb-6">MSME Resources & Blog</h1>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto">
            Stay updated with the latest MSME schemes, regulations, and business insights to grow your enterprise
          </p>
        </div>
      </section>

      {/* Categories Filter */}
      <section className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-4">
            {categories.map((category, index) => (
              <button
                key={index}
                className={`px-6 py-3 rounded-full font-medium whitespace-nowrap cursor-pointer transition-colors ${
                  index === 0 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-white text-gray-700 hover:bg-blue-50 hover:text-blue-600'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Blog Posts Grid */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.map((post) => (
              <article key={post.id} className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow overflow-hidden group cursor-pointer">
                <div className="aspect-video overflow-hidden">
                  <img 
                    src={post.image}
                    alt={post.title}
                    className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <span className="bg-blue-100 text-blue-600 px-3 py-1 rounded-full text-sm font-medium">
                      {post.category}
                    </span>
                    <span className="text-gray-500 text-sm">{post.readTime}</span>
                  </div>
                  <h2 className="text-xl font-bold text-gray-900 mb-3 group-hover:text-blue-600 transition-colors">
                    {post.title}
                  </h2>
                  <p className="text-gray-600 mb-4 leading-relaxed">
                    {post.excerpt}
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-500 text-sm">{post.date}</span>
                    <div className="flex items-center text-blue-600 group-hover:text-blue-800 transition-colors">
                      <span className="text-sm font-medium mr-2">Read More</span>
                      <i className="ri-arrow-right-line"></i>
                    </div>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-20 bg-blue-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Stay Updated with MSME News
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Subscribe to our newsletter for the latest updates on government schemes, regulations, and business opportunities.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
            <input
              type="email"
              placeholder="Enter your email address"
              className="flex-1 px-6 py-4 rounded-lg text-gray-900 text-sm focus:ring-2 focus:ring-orange-500 focus:outline-none"
            />
            <button className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-lg font-semibold whitespace-nowrap cursor-pointer transition-colors">
              Subscribe
            </button>
          </div>
        </div>
      </section>

      {/* Popular Topics */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Popular Topics</h2>
            <p className="text-xl text-gray-600">Most searched topics by our readers</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                icon: "ri-file-text-line",
                title: "Udyam Registration",
                count: "25 Articles"
              },
              {
                icon: "ri-government-line",
                title: "Government Schemes",
                count: "18 Articles"
              },
              {
                icon: "ri-calculator-line",
                title: "GST & Taxation",
                count: "22 Articles"
              },
              {
                icon: "ri-money-dollar-circle-line",
                title: "Business Loans",
                count: "15 Articles"
              }
            ].map((topic, index) => (
              <div key={index} className="bg-white rounded-xl p-6 text-center shadow-lg hover:shadow-xl transition-shadow cursor-pointer">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className={`${topic.icon} text-2xl text-blue-600`}></i>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{topic.title}</h3>
                <p className="text-gray-600">{topic.count}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-orange-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-gray-900 mb-6">
            Need Personal Consultation?
          </h2>
          <p className="text-xl text-gray-700 mb-8 max-w-2xl mx-auto">
            Can't find the information you're looking for? Get personalized guidance from our MSME expert.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="https://wa.me/917985867696" 
              target="_blank" 
              rel="noopener noreferrer"
              className="bg-green-500 hover:bg-green-600 text-white px-8 py-4 rounded-lg font-semibold text-lg inline-flex items-center justify-center whitespace-nowrap cursor-pointer transition-colors"
            >
              <i className="ri-whatsapp-line mr-2 text-xl"></i>
              WhatsApp Consultation
            </a>
            <Link 
              href="/contact"
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-lg font-semibold text-lg inline-flex items-center justify-center whitespace-nowrap cursor-pointer transition-colors"
            >
              <i className="ri-phone-line mr-2"></i>
              Schedule Call
            </Link>
          </div>
        </div>
      </section>

      {/* WhatsApp Float Button */}
      <a 
        href="https://wa.me/917985867696" 
        target="_blank" 
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 bg-green-500 hover:bg-green-600 text-white w-16 h-16 rounded-full flex items-center justify-center shadow-lg z-50 cursor-pointer transition-colors"
      >
        <i className="ri-whatsapp-line text-2xl"></i>
      </a>
    </div>
  );
}
